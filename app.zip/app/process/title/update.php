<?php
    include("../../../require_inc.php");
    $id = $_POST['id'];
    $data['name'] = trim($_POST['name']);
    $data['name_short'] = trim($_POST['name_short']);
    $table = 'titles';
    $user = $_SESSION['is_logined'];
    $result = $h->updateDataBy($data, $table, "where id = $id", $user['id']);
    if ($result)
        echo '1;success';
    else 
        echo '2;error';
?>