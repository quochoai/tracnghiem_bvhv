<?php
    include("../../../require_inc.php");
    $data['block_id'] = trim($_POST['block_id']);
    $dp_id = $_POST['department_id'];
    if (count($dp_id) > 0) {
        $data['department_id'] = implode(",", $dp_id);
    } else 
        $data['department_id'] = 0;
    $tt_id = $_POST['title_id'];
    if (count($tt_id) > 0) {
        $data['title_id'] = implode(",", $tt_id);
    } else 
        $data['title_id'] = 0;
    if (isset($_POST['basic'])) 
        $data['basic'] = $def['basic'];
    else
        $data['basic'] = $def['not_basic'];
    $data['question'] = trim($_POST['question']);

    $as = $_POST['answer'];
    $array_answer = array();
    if (count($as) > 0) {
        foreach ($as as $v) {
            if (trim($v) != '') {
                array_push($array_answer, trim($v));
            }
        }
        $data['answer'] = implode(";;;s_answer;;;", $array_answer);
    }
    $data['right_answer'] = trim($_POST['right_answer']);
    $table = 'qandas';
    $user = $_SESSION['is_logined'];
    $result = $h->insertDataBy($data, $table, $user['id']);
    if ($result)
        echo '1;success';
    else 
        echo '2;error';
?>