<?php
    include("../../../require_inc.php");
    include("../../../phpexcel/Classes/PHPExcel.php");
    
    $file = $_FILES['file']['tmp_name'];

    $objReader = PHPExcel_IOFactory::createReaderForFile($file);
    // get name all sheet in file excel
    $listWorkSheets = $objReader->listWorksheetNames($file);
    
    $objReader->setLoadSheetsOnly('Sheet1');

    $objExcel = $objReader->load($file);
    $sheetData = $objExcel->getActiveSheet()->toArray('null', true, true, true);

    $getHighestColumn = $objExcel->setActiveSheetIndex()->getHighestColumn();
    $getHighestRow = $objExcel->setActiveSheetIndex()->getHighestRow();
    // get name all sheet in file excel
    //$loadAllSheetNames = $objExcel->setActiveSheetIndex()->listWorksheetNames($file);
    for ($i = 2; $i <= $getHighestRow; $i++) {
        $block = $sheetData[$i]['A'];
        if ($block == '0') 
            $data['block_id'] = '0';
        else {
            $bl = $h->getBlockByName($block);
            $data['block_id'] = $bl['id'];
        }
        $department = $sheetData[$i]['B'];
        if ($department == '0') 
            $data['department_id'] = '0';
        else {
            $dp = explode(";dp;", $department);
            $aad = array();
            foreach ($dp as $vd) {
                $d = $h->getDepartmentByName($vd);
                array_push($aad, $d['id']);
            }
            $data['department_id'] = implode(",", $aad);
        }
        $title = $sheetData[$i]['C'];
        if ($title == '0') 
            $data['title_id'] = '0';
        else {
            $tt = explode(";tt;", $title);
            $aat = array();
            foreach ($tt as $vt) {
                $t = $h->getTitleByName($vt);
                array_push($aat, $t['id']);
            }
            $data['title_id'] = implode(",", $aat);
        }
        $data['basic'] = $sheetData[$i]['D'];
        $data['question'] = $sheetData[$i]['E'];
        $ms_answer = '';
        $aa = array();
        if ($sheetData[$i]['F'] != '' && $sheetData[$i]['F'] != 'null')
            array_push($aa, $sheetData[$i]['F']);
        if ($sheetData[$i]['G'] != '' && $sheetData[$i]['G'] != 'null')
            array_push($aa, $sheetData[$i]['G']);
        if ($sheetData[$i]['H'] != '' && $sheetData[$i]['H'] != 'null')
            array_push($aa, $sheetData[$i]['H']);
        if ($sheetData[$i]['I'] != '' && $sheetData[$i]['I'] != 'null')
            array_push($aa, $sheetData[$i]['I']);
        if ($sheetData[$i]['J'] != '' && $sheetData[$i]['J'] != 'null')
            array_push($aa, $sheetData[$i]['J']);
        if ($sheetData[$i]['K'] != '' && $sheetData[$i]['K'] != 'null')
            array_push($aa, $sheetData[$i]['K']);
        if ($sheetData[$i]['L'] != '' && $sheetData[$i]['L'] != 'null')
            array_push($aa, $sheetData[$i]['L']);
        if ($sheetData[$i]['M'] != '' && $sheetData[$i]['M'] != 'null')
            array_push($aa, $sheetData[$i]['M']);
        if (count($aa) > 0) {
            $data['answer'] = implode(";;;s_answer;;;", $aa);
        } else 
            $data['answer'] = '';
        $data['right_answer'] = $sheetData[$i]['N'];
        $table = 'qandas';
        $user = $_SESSION['is_logined'];
        $n = $h->getNumberByQuestion($data['question']);
        if ($n)
            continue;
        else
            $result = $h->insertDataBy($data, $table, $user['id']);
    }
    echo '1;success';
?>