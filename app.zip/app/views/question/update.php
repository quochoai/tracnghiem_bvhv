<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header container-fluid">
              <div class="row">
                <h3 class="card-title col-md-10">
                    <?php 
                        $qa = $h->getQuestionById($pqh[1]);
                        echo $lang['text_update_question']
                    ?>
                </h3>
                <div class="col-md-2"><a class="float-right" href="<?php echo $def['link_question'] ?>" title="<?php echo $lang['back'] ?>"><i class="fas fa-undo-alt"></i></a></div>
              </div>
          </div>
          <!-- /.card-header -->
          <form action="<?php echo $def['link_process_update_question'] ?>" method="post" id="form_jquery" role="form">
            <input type="hidden" name="id" value="<?php echo $pqh[1] ?>" />
              <div class="card-body container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $lang['block_exam'] ?></label>
                            <select class="form-control select2 select2-success" data-dropdown-css-class="select2-success" name="block_id" id="block_id" style="width: 100%;">
                                <option value="0"><?php echo $lang['choose_block'] ?></option>
                            <?php
                                $blocks = $h->getBlocks();
                                if (count($blocks) > 0) {
                                    foreach ($blocks as $block) {
                                        if ($block['id'] == $qa['block_id']) $selected = ' selected';
                                        else $selected = '';
                                        echo '<option value="'.$block['id'].'"'.$selected.'>'.$block['name'].'</option>';
                                    }
                                }
                            ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $lang['department_exam'] ?></label>
                            <div class="select2-green">
                                <select class="select2" multiple="multiple" name="department_id[]" id="department_id" data-placeholder="<?php echo $lang['select_department'] ?>" data-dropdown-css-class="select2-green" style="width: 100%;">
                                    <option value="0"><?php echo $lang['choose_department'] ?></option>
                                <?php
                                    $array_dp = explode(",", $qa['department_id']);
                                    $departments = $h->getDistinctDepartments();
                                    if (count($departments) > 0) {
                                        foreach ($departments as $department) {
                                            if (in_array($department['id'], $array_dp)) $selected = ' selected';
                                            else $selected = '';
                                            echo '<option value="'.$department['id'].'"'.$selected.'>'.$department['name'].'</option>';
                                        }
                                    }
                                ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label><?php echo $lang['title_exam'] ?></label>
                            <div class="select2-green">
                                <select class="select2" multiple="multiple" name="title_id[]" id="title_id" data-placeholder="<?php echo $lang['select_title'] ?>" data-dropdown-css-class="select2-green" style="width: 100%;">
                                <?php
                                    $array_tt = explode(",", $qa['title_id']);
                                    $titles = $h->getTitles();
                                    if (count($titles) > 0) {
                                        foreach ($titles as $title) {
                                            if (in_array($title['id'], $array_tt)) $selected = ' selected';
                                            else $selected = '';
                                            echo '<option value="'.$title['id'].'"'.$selected.'>'.$title['name'].'</option>';
                                        }
                                    }
                                ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="col-form-label" for="basic"><?php echo $lang['basic'] ?></label><br />
                            <input type="checkbox" name="basic"<?php if ($qa['basic'] == $def['basic']) echo ' checked'; ?> data-bootstrap-switch data-off-color="danger" data-on-color="success">
                            <small class="form-text text-danger"><?php echo $lang['is_basic'] ?></small>
                        </div>
                    </div>
                    <div class="col-md-12"><small class="form-text text-danger"><?php echo $lang['not_choose_is_general'] ?></small></div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-form-label" for="name"><?php echo $lang['questions'] ?></label>
                            <textarea class="form-control" rows="3" name="question" id="question" placeholder="<?php echo $lang['placeholder_question'] ?>"><?php echo $qa['question'] ?></textarea>
                            <small id="questionHelp" class="form-text text-danger"></small>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-form-label" for="name"><?php echo $lang['suggest_answer'] ?></label>
                            <?php 
                                $aa = explode(";;;s_answer;;;", $qa['answer']);
                                $msga = '';
                                foreach ($aa as $ka => $va) {
                                    $ka = $ka + 1;
                                    $msga .= '<input type="text" class="form-control mt-2" name="answer[]" id="answer'.$ka.'" value="'.$va.'" />';
                                }
                                echo $msga;
                            ?>
                            
                            <span id="add_answer"></span><br />
                                
                            <small class="form-text text-danger"><?php echo $lang['note_suggest_answer'] ?></small><br />
                            <small id="answerHelp" class="form-text text-danger"></small>
                            <a class="btn btn-success add_suggest_answer"><?php echo $lang['add_suggest_answer'] ?></a> 
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="col-form-label" for="name"><?php echo $lang['right_answer'] ?></label>
                            <input type="text" class="form-control" name="right_answer" id="right_answer" placeholder="<?php echo $lang['placeholder_right_answer'] ?>" value="<?php echo $qa['right_answer'] ?>" />
                            <small id="rightAnswer" class="form-text text-danger"></small>
                        </div>
                    </div>
                </div>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                  <button type="submit" id="submit_question" class="btn btn-success"><?php echo $lang['save']; ?> <i class="fas fa-save"></i></button>
                  <button type="button" id="cancel" class="btn btn-default ml-2"><?php echo $lang['cancel'] ?> <i class="fas fa-undo"></i></button>
              </div>
          </form>
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<!-- /.content -->