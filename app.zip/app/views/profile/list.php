<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header container-fluid">
            <div class="row">
                <h3 class="col-md-10 card-title">
                    <?php echo $lang['manage_profile'] ?>
                </h3>
                <div class="col-md-2"><a class="float-right btn btn-success" href="<?php echo $def['link_create_profile'] ?>/"><?php echo $lang['addNew'] ?></a></div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="profiles" class="table table-bordered table-hover">
              <thead>
              <tr>
                <th width="7%" align="center"><?php echo $lang['no.'] ?></th>
                <th width="15%" align="center"><?php echo $lang['profile_code'] ?></th>
                <th width="20%" align="center"><?php echo $lang['profile_fullname'] ?></th>
                <th width="10%" align="center"><?php echo $lang['profile_birthday'] ?></th>
                <th width="12%" align="center"><?php echo $lang['profile_role'] ?></th>
                <th width="10%" align="center"><?php echo $lang['profile_active'] ?></th>
                <th width="10%" align="center"><?php echo $lang['profile_active_exam'] ?></th>
                <th width="10%" align="center"><?php echo $lang['actions'] ?></th>
              </tr>
              </thead>
              <tbody>
               <?php
                if ($role == $def['role_organizer'])
                  $profiles = $h->getProfiles();
                else
                  $profiles = $h->getProfilesRole($profile['id']);
                $msg_profile = '';
                if (count($profiles) > 0) {
                    foreach ($profiles as $kp => $profile_list) {
                        $no = $kp + 1;
                        $block = $h->getBlockById($profile_list['block_id']);
                        $department = $h->getDepartmentById($profile_list['department_id']);
                        $title = $h->getTitleById($profile_list['title_id']);

                        if ($profile_list['role'] == $def['role_organizer']) 
                            $text_role = $lang['text_role_organizer'];
                        elseif ($profile_list['role'] == $def['role_admin_staff'])
                            $text_role = $lang['text_role_admin_staff'];
                        else 
                            $text_role = $lang['text_role_candidate'];

                        if ($profile_list['active'] == $def['actived'])
                            $text_active = '<i class="fas fa-check-square btn-success clsactive" data-id="'.$profile_list['id'].'" style="cursor:pointer;" title="'.$lang['click_to_inactive'].'"></i>';
                        else
                            $text_active = '<i class="fas fa-square btn-danger clsactive" data-id="'.$profile_list['id'].'" style="cursor:pointer;" title="'.$lang['click_to_active'].'"></i>';
                        
                        if ($profile_list['active_exam'] == $def['actived'])
                            $text_active_exam = '<i class="fas fa-check-square btn-success clsactive_exam" data-id="'.$profile_list['id'].'" style="cursor:pointer;" title="'.$lang['click_to_inactive_exam'].'"></i>';
                        else
                            $text_active_exam = '<i class="fas fa-square btn-danger clsactive_exam" data-id="'.$profile_list['id'].'" style="cursor:pointer;" title="'.$lang['click_to_inactive_exam'].'"></i>';

                        $msg_profile .= '<tr>';
                        $msg_profile .= ' <td align="center">'.$no.'</td>';
                        /*$msg_profile .= ' <td>'.$block['name'].'</td>';
                        $msg_profile .= ' <td>'.$department['name'].'</td>';
                        $msg_profile .= ' <td>'.$title['name'].'</td>';*/
                        $msg_profile .= ' <td>'.$profile_list['profile_code'].'</td>';
                        $msg_profile .= ' <td>'.$profile_list['fullname'].'</td>';
                        $msg_profile .= ' <td>'.$profile_list['birthday'].'</td>';
                        $msg_profile .= ' <td>'.$text_role.'</td>';
                        $msg_profile .= ' <td align="center">'.$text_active.'</td>';
                        $msg_profile .= ' <td align="center">'.$text_active_exam.'</td>';
                        $msg_profile .= ' <td align="center"><a class="btn btn-primary btn-sm" href="'.$def['link_update_profile'].'/'.$profile_list['id'].'" title="'.$lang['update'].'"><i class="fas fa-edit"></i></a> | <a class="btn btn-danger btn-sm delete" data-id="'.$profile_list['id'].'" title="'.$lang['delete'].'"><i class="fas fa-trash-alt"></i></a></a> </td>';
                        $msg_profile .= '</tr>';
                    }
                }
                echo $msg_profile;
              ?>
              </tbody>
              <tfoot>
              <tr>
              <th width="7%" align="center"><?php echo $lang['no.'] ?></th>
                <!--<th width="13%" align="center"><?php echo $lang['block_name'] ?></th>
                <th width="13%" align="center"><?php echo $lang['department_name'] ?></th>
                <th width="13%" align="center"><?php echo $lang['title_name'] ?></th>-->
                <th width="12%" align="center"><?php echo $lang['profile_code'] ?></th>
                <th width="20%" align="center"><?php echo $lang['profile_fullname'] ?></th>
                <th width="12%" align="center"><?php echo $lang['profile_birthday'] ?></th>
                <th width="12%" align="center"><?php echo $lang['profile_role'] ?></th>
                <th width="10%" align="center"><?php echo $lang['profile_active'] ?></th>
                <th width="10%" align="center"><?php echo $lang['profile_active_exam'] ?></th>
                <th width="10%" align="center"><?php echo $lang['actions'] ?></th>
              </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<!-- /.content -->