<?php
    if (isset($_REQUEST['pqh'])) {
        $pqh = explode("/", trim($_REQUEST['pqh']));
        switch ($pqh[0]) {
            // block
            case $def['get_link_block']:
                $title = $lang['manage_block'];
                break;
            case $def['link_create_block']:
                $title = $lang['text_add_block'];
                break;
            case $def['link_update_block']:
                $title = $lang['text_update_block'];
                break;
            // department
            case $def['get_link_department']:
                $title = $lang['manage_department'];
                break;
            case $def['link_create_department']:
                $title = $lang['text_add_department'];
                break;
            case $def['link_update_department']:
                $title = $lang['text_update_department'];
                break;
            // title
            case $def['link_title']:
                $title = $lang['manage_title'];
                break;
            case $def['link_create_title']:
                $title = $lang['text_add_title'];
                break;
            case $def['link_update_title']:
                $title = $lang['text_update_title'];
                break;
            // profile
            case $def['get_link_profile']:
                $title = $lang['manage_profile'];
                break;
            case $def['link_create_profile']:
                $title = $lang['text_add_profile'];
                break;
            case $def['link_update_profile']:
                $title = $lang['text_update_profile'];
                break;
            case $def['link_change_password']:
                $title = $lang['change_password'];
                break;
            // exam
            case $def['get_link_exam']:
                $title = $lang['manage_exams'];
                break;
            case $def['link_create_exam']:
                $title = $lang['text_add_exam'];
                break;
            case $def['link_update_exam']:
                $title = $lang['text_update_exam'];
                break;
            // exam block follow exam
            case $def['get_link_each_exam']:
                $exam = $h->getExamById($pqh[1]);
                $title = $lang['manage_each_exam'].$exam['name'];
                break;
            case $def['link_create_each_exam']:
                $exam = $h->getExamById($pqh[1]);
                $title = $lang['text_add_each_exam'].' '.$exam['name'];
                break;
            case $def['link_update_each_exam']:
                $title = $lang['text_update_each_exam'];
                break;
            // questions
            case $def['get_link_question']:
                $title = $lang['manage_questions'];
                break;
            case $def['link_create_question']:
                $title = $lang['text_add_question'];
                break;
            case $def['link_update_question']:
                $title = $lang['text_update_question'];
                break;
            case $def['link_import_question']:
                $title = $lang['import_question'];
                break;
        }
    } else {
        $title = $lang['title_website'];
    }
    echo $title;
?>