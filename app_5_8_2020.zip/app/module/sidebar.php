<?php
    include($sidebar);
?>