<?php
    include($sidebar);
?>